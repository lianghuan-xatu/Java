package com.itheima.demo03.hashCode;

public class Person extends  Object{
    //重写hashCode方法

    @Override
    public int hashCode() {
        return  1;
    }
}
